#pragma once

enum ConsoleColor {
  CC_Black = 0,
  CC_Blue,
  CC_Green,
  CC_Cyan,
  CC_Red,
  CC_Magenta,
  CC_Brown,
  CC_LightGray,
  CC_DarkGray,
  CC_LightBlue,
  CC_LightGreen,
  CC_LightCyan,
  CC_LightRed,
  CC_LightMagenta,
  CC_Yellow,
  CC_White
};
