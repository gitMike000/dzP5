#ifndef VISITOR_H
#define VISITOR_H

#include "Bomb.h"
#include "Plane.h"
#include "MyTools.h"

class Bomb;
class Plane;

class Visitor {

public:
    virtual void log(Bomb& b) const = 0;
    virtual void log(Plane& p) const = 0;

};

class LogVisitor: public Visitor {

public:

    void log(Bomb& b) const override;

    void log(Plane& p) const override;

};


#endif // VISITOR_H
