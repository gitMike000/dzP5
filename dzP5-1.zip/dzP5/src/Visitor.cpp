#include "include/Visitor.h"

void LogVisitor::log(Bomb& b) const  {
    MyTools::FileLoggerSingletone::getInstance().WriteToLog(std::string(__func__) + " Speed bomb= ", b.GetSpeed());
    MyTools::FileLoggerSingletone::getInstance().WriteToLog(std::string(__func__) + " dx = ", b.GetDirectionX());
    MyTools::FileLoggerSingletone::getInstance().WriteToLog(std::string(__func__) + " dy = ", b.GetDirectionY());
};

void LogVisitor::log(Plane& p) const  {
    MyTools::FileLoggerSingletone::getInstance().WriteToLog(std::string(__func__) + " Speed plane= ", p.GetSpeed());
    MyTools::FileLoggerSingletone::getInstance().WriteToLog(std::string(__func__) + " dx = ", p.GetDirectionX());
    MyTools::FileLoggerSingletone::getInstance().WriteToLog(std::string(__func__) + " dy = ", p.GetDirectionY());
};
