#include "include/Bomb.h"
#include <iostream>
#include "include/ScreenSingleton.h"
#include "include/Tank.h"
#include "include/House.h"

void Bomb::Draw() const {
  //ScreenSingleton::getInstance().SetColor(CC_LightMagenta);
  ScreenSingleton::getInstance().GotoXY(x, y);
  std::cout << "*";
}

DestroyableGroundObject*
      Bomb::CheckDestoyableObjects(std::vector<DestroyableGroundObject*> vecDestoyableObjects)
{
  const double size = GetWidth();
  const double size_2 = size / 2;
  for (size_t i = 0; i < vecDestoyableObjects.size(); i++) {
    const double x1 = GetX() - size_2;
    const double x2 = x1 + size;
    if (vecDestoyableObjects[i]->HandleInsideCheck(x1,x2)) {
        return vecDestoyableObjects[i];
        //break;
    }
  }
  return nullptr;
};

//bool Bomb::NotifyObserver() {
//  for (size_t i=0;i<observers.size(); i++) {
//   observers[i]->HandleInsideCheck();
//  };
//  return true;
//};

//void Bomb::AddObserver(Observer* o) {
//  observers.push_back(o);
//};
