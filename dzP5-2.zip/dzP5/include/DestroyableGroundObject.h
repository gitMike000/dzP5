#pragma once

#include <stdint.h>

#include "GameObject.h"
#include "Observ.h"

class DestroyableGroundObject : public GameObject, public Observer
{
public:

    virtual bool  isInside(double x1, double x2) const = 0;

    virtual inline uint16_t GetScore() const = 0;

    virtual bool HandleInsideCheck(const double x1, const double x2) const = 0;

protected:

};
