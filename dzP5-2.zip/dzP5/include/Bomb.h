#pragma once

#include "DynamicObject.h"
#include "Observ.h"
#include "DestroyableGroundObject.h"
#include "SBomber.h"

//#include <vector>

class Observer;
class SBomber;

class Bomb : public DynamicObject, Observable
{
public:
    //Bomb();
    //~Bomb();

	static const uint16_t BombCost = 10; // ��������� ����� � �����

	void Draw() const override;   

    DestroyableGroundObject* CheckDestoyableObjects(std::vector<DestroyableGroundObject*> vecDestoyableObjects);
                    // void NotifyObserver() override;
//    std::vector<DestroyableGroundObject*> vecDestoyableObjects; //possible variant
                   // std::vector<Observer*> observers;
    //    void AddObserver(Observer* o) override;


private:

};

