#ifndef OBSERV_H
#define OBSERV_H

class Observer {
public:
//    Observer();
//    ~Observer();

    virtual bool HandleInsideCheck(const double x1, const double x2) const =0;
     // virtual void HandleEvent();
};

class Observable {
public:

//    virtual void AddObserver(Observer* o);
//    virtual void RemoveObserver(Observer* o);
//    virtual bool NotifyObserver();
};

#endif // OBSERV_H
